package com.example.week2_4;

import android.app.Activity;

/**
 * Created by 205호-25 on 2015-09-18.
 */
public class SecondActivity extends Activity {
}
