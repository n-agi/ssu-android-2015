package com.example.week2_2;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.app.Service;

/**
 * Created by 205호-25 on 2015-09-18.
 */
public class MyAlarmService extends Service {
    public IBinder onBind(Intent intent) {
        return null;
    }
}
