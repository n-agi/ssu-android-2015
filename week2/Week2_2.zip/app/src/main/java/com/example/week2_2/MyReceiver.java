package com.example.week2_2;

import android.content.BroadcastReceiver;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
/**
 * Created by 205호-25 on 2015-09-18.
 */
public class MyReceiver extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent) {

        String name = intent.getAction();

        if(name.equals("arabiannight.tistory.com.sendreciver.gogogo")){
            Toast.makeText
                    (context, "정상적으로 값을 받았습니다.", Toast.LENGTH_SHORT).show();
        }
    }
}
